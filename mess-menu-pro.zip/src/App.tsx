import { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Clock, 
  Calendar, 
  ChevronDown, 
  Star, 
  Utensils, 
  Info, 
  X, 
  Heart,
  MessageSquareShare,
  Coffee,
  Sun,
  Cookie,
  Moon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MESS_DATA, MESS_LIST, MealType, WeeklyTimetable } from './data/timetable';

// --- Constants & Helper Logic ---

const REVIEWS_LIMIT = 5;
const QUICK_TAGS = ["Too Salty", "Perfect", "Spicy", "Cold", "Fresh"];

// Smart categorization helper
const getCategory = (item: string): string => {
  const lowercase = item.toLowerCase();
  if (lowercase.includes('chicken') || lowercase.includes('egg') || lowercase.includes('paneer') || lowercase.includes('dal') || lowercase.includes('chana') || lowercase.includes('rajma') || lowercase.includes('kofta')) return "Main";
  if (lowercase.includes('rice') || lowercase.includes('roti') || lowercase.includes('puri') || lowercase.includes('pav') || lowercase.includes('paratha')) return "Staple";
  if (lowercase.includes('tea') || lowercase.includes('coffee') || lowercase.includes('milk') || lowercase.includes('juice') || lowercase.includes('shake')) return "Beverage";
  if (lowercase.includes('salad') || lowercase.includes('pickle') || lowercase.includes('curd') || lowercase.includes('raita')) return "Side";
  if (lowercase.includes('fruit') || lowercase.includes('halwa') || lowercase.includes('custard')) return "Dessert";
  return "Accompany";
};

const getMealType = (hour: number, minute: number): MealType => {
  const timeNum = hour * 100 + minute;
  if (timeNum >= 700 && timeNum < 1030) return 'Breakfast';
  if (timeNum >= 1200 && timeNum < 1500) return 'Lunch';
  if (timeNum >= 1630 && timeNum < 1830) return 'Snacks';
  return 'Dinner';
};

const getMealIcon = (meal: MealType) => {
  switch (meal) {
    case 'Breakfast': return <Coffee className="w-5 h-5" />;
    case 'Lunch': return <Sun className="w-5 h-5" />;
    case 'Snacks': return <Cookie className="w-5 h-5" />;
    case 'Dinner': return <Moon className="w-5 h-5" />;
  }
};

export default function App() {
  // --- State ---
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedMess, setSelectedMess] = useState(MESS_LIST[0]);
  const [isMessSelectorOpen, setIsMessSelectorOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userRating, setUserRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewsCount, setReviewsCount] = useState(214);
  const [averageRating, setAverageRating] = useState(4.8);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [tagStats, setTagStats] = useState<Record<string, number>>({
    "Too Salty": 3,
    "Perfect": 42,
    "Spicy": 12,
    "Cold": 1,
    "Fresh": 38
  });
  const [isLoading, setIsLoading] = useState(true);

  // --- Refs ---
  const dropdownRef = useRef<HTMLDivElement>(null);

  // --- Effects ---
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    const loadTimer = setTimeout(() => setIsLoading(false), 800);
    return () => {
      clearInterval(timer);
      clearTimeout(loadTimer);
    };
  }, []);

  // Handle outside click for custom dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsMessSelectorOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // --- Derived State ---
  const dayName = currentTime.toLocaleDateString('en-US', { weekday: 'long' });
  const dateString = currentTime.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const timeString = currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  
  const currentMeal = useMemo(() => {
    return getMealType(currentTime.getHours(), currentTime.getMinutes());
  }, [currentTime]);

  const currentMenuItems = useMemo(() => {
    const messData = MESS_DATA[selectedMess] as WeeklyTimetable;
    const menuStr = messData[dayName]?.[currentMeal] || "";
    return menuStr.split(',').map(item => item.trim()).filter(Boolean);
  }, [selectedMess, dayName, currentMeal]);

  // --- Handlers ---
  const handleRating = (rating: number) => {
    setUserRating(rating);
    const newCount = reviewsCount + 1;
    const newAverage = ((averageRating * reviewsCount) + rating) / newCount;
    setAverageRating(Number(newAverage.toFixed(1)));
    setReviewsCount(newCount);
  };

  const toggleTag = (tag: string) => {
    const isAdding = !selectedTags.includes(tag);
    setSelectedTags(prev => isAdding ? [...prev, tag] : prev.filter(t => t !== tag));
    if (isAdding) {
      setTagStats(prev => ({ ...prev, [tag]: (prev[tag] || 0) + 1 }));
    }
  };

  // --- UI Components ---
  
  const LoadingShimmer = () => (
    <div className="flex flex-col gap-6 animate-pulse">
      <div className="flex justify-between">
        <div className="space-y-2">
          <div className="h-4 bg-white/10 rounded-full w-24" />
          <div className="h-10 bg-white/10 rounded-xl w-48" />
        </div>
        <div className="h-12 bg-white/10 rounded-full w-12" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[1, 2, 3, 4].map(i => <div key={i} className="h-24 bg-white/10 rounded-[24px]" />)}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans overflow-x-hidden relative">
      {/* Background Ambient Glows */}
      <div className="absolute top-[-100px] left-[-100px] w-80 h-80 bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-50px] right-[-50px] w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Navigation Bar */}
      <header className="h-20 md:h-24 px-4 md:px-12 flex items-center justify-between border-b border-white/5 bg-slate-900/60 backdrop-blur-md z-30 sticky top-0">
        <div className="flex items-center gap-3 md:gap-4">
          <motion.div 
            whileHover={{ rotate: 10 }}
            className="w-10 h-10 md:w-12 md:h-12 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20"
          >
            <Utensils className="w-5 h-5 md:w-7 md:h-7 text-slate-900" />
          </motion.div>
          <span className="text-xl md:text-2xl font-black tracking-tighter text-white">
            Campus<span className="text-emerald-400">Cuisine</span>
          </span>
        </div>

        <div className="flex items-center gap-3 md:gap-10">
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.2em]">{dayName}</span>
            <span className="text-xl font-bold font-mono tracking-tighter text-white">
              {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
          
          <div className="relative" ref={dropdownRef}>
            <button 
              onClick={() => setIsMessSelectorOpen(!isMessSelectorOpen)}
              className="h-10 md:h-14 px-3 md:px-5 bg-white/5 border border-white/10 rounded-xl md:rounded-2xl flex items-center gap-2 md:gap-3 cursor-pointer hover:bg-white/10 transition-all duration-300 group"
            >
              <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.5)]" />
              <span className="font-bold text-[10px] md:text-sm max-w-[80px] sm:max-w-[120px] truncate md:max-w-none">{selectedMess}</span>
              <ChevronDown className={`w-3 h-3 md:w-4 md:h-4 text-slate-400 transition-transform ${isMessSelectorOpen ? 'rotate-180' : ''}`} />
            </button>
            
            <AnimatePresence>
              {isMessSelectorOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 5 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute right-0 mt-2 w-64 glass rounded-2xl overflow-hidden shadow-2xl z-40 p-2"
                >
                  {MESS_LIST.map((mess) => (
                    <button
                      key={mess}
                      onClick={() => {
                        setSelectedMess(mess);
                        setIsMessSelectorOpen(false);
                      }}
                      className={`w-full text-left px-4 py-3 rounded-xl transition-all duration-200 text-sm font-semibold mb-1 last:mb-0 ${
                        selectedMess === mess ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      {mess}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-10 grid grid-cols-12 gap-6 md:gap-8 z-10">
        
        {/* Left Column: Current Meal Service */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-6">
          <div className="p-6 md:p-10 glass-card relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 text-right hidden md:block">
              <div className="text-4xl font-black text-white flex items-center justify-end gap-2 leading-none">
                <Star className="w-8 h-8 fill-yellow-400 text-yellow-400" />
                {averageRating}
              </div>
              <div className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mt-1">Student Verdict</div>
            </div>

            <div className="flex flex-col mb-8 md:mb-10">
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-black rounded-full uppercase tracking-[0.2em] border border-emerald-500/20">
                  Live Service
                </span>
                <span className="text-slate-500 text-[10px] font-bold flex items-center gap-1 uppercase tracking-widest">
                  <Clock className="w-3 h-3" />
                  Till {currentMeal === 'Breakfast' ? '10:30' : currentMeal === 'Lunch' ? '15:00' : currentMeal === 'Snacks' ? '18:30' : '22:00'}
                </span>
              </div>
              <h1 className="text-4xl md:text-6xl font-black text-white leading-none tracking-tight">
                {currentMeal} <span className="text-slate-700">Menu</span>
              </h1>
            </div>

            {isLoading ? <LoadingShimmer /> : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-4"
              >
                {currentMenuItems.length > 0 ? currentMenuItems.map((item, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    key={`${item}-${idx}`} 
                    className="p-5 md:p-6 bg-slate-900/40 rounded-[28px] border border-white/5 transition-all duration-300 hover:border-emerald-500/40 hover:bg-slate-900/60 group"
                  >
                    <div className="flex justify-between items-start mb-3">
                       <span className="text-base md:text-lg font-black text-white group-hover:text-emerald-400 transition-colors uppercase tracking-tight leading-tight">{item}</span>
                       <div className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-white/5 flex items-center justify-center text-slate-500 group-hover:bg-emerald-500/20 transition-all shrink-0">
                          {getMealIcon(currentMeal)}
                       </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-[2px] w-4 md:w-8 bg-emerald-500/50 rounded-full" />
                      <span className="text-[9px] md:text-[10px] text-emerald-400/80 font-black uppercase tracking-[0.2em]">{getCategory(item)}</span>
                    </div>
                  </motion.div>
                )) : (
                  <div className="col-span-1 sm:col-span-2 py-12 md:py-16 bg-white/5 border border-dashed border-white/10 rounded-[32px] flex flex-col items-center justify-center text-slate-500">
                    <Moon className="w-10 h-10 md:w-12 md:h-12 mb-4 opacity-10" />
                    <p className="font-black uppercase tracking-widest text-[9px] md:text-xs italic">Service Offline</p>
                  </div>
                )}
              </motion.div>
            )}

            {/* Frictionless Review Section */}
            <div className="mt-8 md:mt-12 pt-8 md:pt-10 border-t border-white/10">
              <div className="flex items-center justify-between mb-6 md:mb-8">
                <div>
                  <h3 className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Quality Control</h3>
                  <p className="text-[9px] text-slate-600 font-bold mt-1 uppercase tracking-widest">{reviewsCount} daily reports</p>
                </div>
                <div className="flex md:hidden items-center gap-2 px-3 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20">
                  <Star className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                  <span className="font-black text-emerald-400 tracking-tighter text-xs">{averageRating}</span>
                </div>
              </div>

              <div className="flex flex-col md:flex-row items-center gap-6 md:gap-10">
                <div className="flex gap-1.5 md:gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <motion.button
                      key={star}
                      whileHover={{ scale: 1.15 }}
                      whileTap={{ scale: 0.9 }}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      onClick={() => handleRating(star)}
                      className={`w-9 h-9 md:w-12 md:h-12 rounded-[14px] md:rounded-[18px] bg-white/5 border transition-all duration-300 text-xl md:text-2xl flex items-center justify-center ${
                        (hoverRating || userRating) >= star 
                          ? 'bg-yellow-400/20 border-yellow-400/40 text-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.1)]' 
                          : 'border-white/5 text-slate-800'
                      }`}
                    >
                      ★
                    </motion.button>
                  ))}
                </div>
                
                <div className="flex flex-wrap gap-1.5 md:gap-2.5 justify-center">
                  {QUICK_TAGS.map(tag => {
                    const isSelected = selectedTags.includes(tag);
                    return (
                      <div key={tag} className="flex flex-col items-center gap-1.5 min-w-[70px] md:min-w-[90px]">
                        <motion.button
                          whileTap={{ scale: 0.95 }}
                          onClick={() => toggleTag(tag)}
                          className={`w-full px-3 md:px-5 py-2 md:py-2.5 rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] border transition-all duration-300 ${
                            isSelected 
                              ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 shadow-lg shadow-emerald-500/10' 
                              : 'bg-white/5 border-white/5 text-slate-500 hover:text-slate-300 hover:border-white/20'
                          }`}
                        >
                          {tag}
                        </motion.button>
                        <AnimatePresence>
                          {isSelected && (
                            <motion.span 
                              initial={{ opacity: 0, y: -4 }} 
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -4 }}
                              className="text-[8px] font-black text-emerald-500/60 uppercase tracking-tighter"
                            >
                              {tagStats[tag]} Agreed
                            </motion.span>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Sidebar */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-6 md:gap-8">
          <div className="p-6 md:p-8 glass-card border-white/5 flex flex-col min-h-[500px]">
            <div className="flex justify-between items-center mb-8">
              <h3 className="font-black text-xl tracking-tight text-white uppercase italic">Daily Log</h3>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="text-[9px] font-black text-emerald-400 uppercase tracking-[0.2em] border border-emerald-500/20 px-4 py-2 rounded-full hover:bg-emerald-500/10 transition-all"
              >
                Expand All
              </button>
            </div>

            <div className="space-y-4 mb-10">
              {(['Breakfast', 'Lunch', 'Snacks', 'Dinner'] as MealType[]).map((meal) => {
                const isCurrent = meal === currentMeal;
                const menuItems = (MESS_DATA[selectedMess] as WeeklyTimetable)[dayName]?.[meal] || "";
                const menuArray = menuItems.split(',').map(m => m.trim()).filter(Boolean);
                
                return (
                  <div 
                    key={meal}
                    className={`flex items-start gap-4 p-5 rounded-[28px] border transition-all duration-300 ${
                      isCurrent 
                        ? 'bg-emerald-500/10 border-emerald-500/30 shadow-lg shadow-emerald-500/5' 
                        : 'bg-white/5 border-brand-green/5 opacity-50 hover:opacity-100 hover:border-white/10'
                    }`}
                  >
                    <div className="mt-1 flex flex-col items-center shrink-0">
                      <div className={`w-1.5 h-8 md:h-12 rounded-full ${isCurrent ? 'bg-emerald-500' : 'bg-slate-700'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className={`text-[9px] font-black uppercase tracking-[0.3em] ${isCurrent ? 'text-emerald-400' : 'text-slate-500'}`}>
                          {meal} {isCurrent && "• Online"}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-slate-200 line-clamp-2 md:line-clamp-none">
                        {menuArray.slice(0, 4).join(', ')}{menuArray.length > 4 && '...'}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-auto">
              <div className="p-6 md:p-8 rounded-[38px] bg-gradient-to-br from-emerald-500 to-emerald-700 text-slate-950 relative overflow-hidden group shadow-2xl">
                <div className="absolute top-[-20px] right-[-20px] w-32 h-32 bg-white/20 rounded-full blur-2xl group-hover:scale-110 transition-transform duration-700" />
                <Calendar className="w-10 h-10 mb-4 opacity-40 rotate-12" />
                <div className="text-[10px] font-black uppercase tracking-[0.4em] opacity-60 mb-2">Campus Bulletin</div>
                <p className="font-extrabold text-lg leading-[1.1] tracking-tighter">
                  Potentially <span className="underline decoration-white/30">Special Feast</span> for upcoming festival. Update pending from caterers.
                </p>
                <div className="mt-4 flex items-center gap-2">
                  <div className="h-1 w-full bg-slate-950/20 rounded-full overflow-hidden">
                    <motion.div animate={{ x: ['-100%', '100%'] }} transition={{ repeat: Infinity, duration: 3, ease: 'linear' }} className="h-full w-1/2 bg-white/50" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="h-20 px-6 md:px-12 flex items-center justify-between border-t border-white/5 text-[9px] font-black uppercase tracking-[0.4em] text-slate-600 bg-slate-900/80 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(52,211,153,0.4)]" />
          Server Synced
        </div>
        <div className="hidden sm:block">
          Crafted by <span className="text-emerald-400">Naman Rai</span>
        </div>
        <div>v1.2.0</div>
      </footer>

      {/* Standard Timetable Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-8"
          >
            <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-2xl" onClick={() => setIsModalOpen(false)} />
            
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 30 }}
              className="relative w-full max-w-6xl glass-card overflow-hidden flex flex-col max-h-[92vh] shadow-3xl bg-slate-900/60"
            >
              <div className="p-6 md:p-10 flex items-center justify-between border-b border-white/5 bg-white/5">
                <div>
                  <h2 className="text-3xl font-black tracking-tighter text-white uppercase flex items-center gap-4">
                    Master <span className="text-emerald-400 italic">Timetable</span>
                  </h2>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] mt-1">Safal Mess Management Interface</p>
                </div>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all border border-white/5"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-auto p-4 md:p-8 scrollbar-hide">
                <table className="w-full border-separate border-spacing-y-3 min-w-[800px]">
                  <thead>
                    <tr className="text-left">
                      <th className="px-6 pb-4 text-[9px] font-black text-slate-600 uppercase tracking-[0.4em]">Service Day</th>
                      <th className="px-6 pb-4 text-[9px] font-black text-emerald-400 uppercase tracking-[0.4em]">Breakfast</th>
                      <th className="px-6 pb-4 text-[9px] font-black text-yellow-400 uppercase tracking-[0.4em]">Lunch</th>
                      <th className="px-6 pb-4 text-[9px] font-black text-brand-cyan uppercase tracking-[0.4em]">Snacks</th>
                      <th className="px-6 pb-4 text-[9px] font-black text-purple-400 uppercase tracking-[0.4em]">Dinner</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(MESS_DATA[selectedMess] as WeeklyTimetable).map(([day, menu]) => {
                      const isToday = day === dayName;
                      return (
                        <tr 
                          key={day} 
                          className={`transition-all duration-300 rounded-[2rem] overflow-hidden ${
                            isToday ? 'bg-emerald-500/10' : 'bg-white/[0.02] hover:bg-white/5'
                          }`}
                        >
                          <td className={`px-6 py-8 align-top font-black italic uppercase tracking-tighter text-xl ${isToday ? 'text-emerald-400' : 'text-slate-300'}`}>
                            {day}
                            {isToday && <div className="text-[10px] not-italic font-black text-emerald-500/60 uppercase tracking-[0.5em] mt-1 animate-pulse">Now Serving</div>}
                          </td>
                          {(['Breakfast', 'Lunch', 'Snacks', 'Dinner'] as MealType[]).map((meal) => {
                            const isCurrentMeal = isToday && meal === currentMeal;
                            return (
                              <td 
                                key={meal} 
                                className={`px-6 py-8 align-top text-[11px] leading-relaxed transition-all duration-300 max-w-[200px] ${
                                  isCurrentMeal ? 'text-emerald-200 font-extrabold bg-emerald-500/10' : 'text-slate-400 font-medium'
                                }`}
                              >
                                {menu[meal] || "N/A"}
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}


