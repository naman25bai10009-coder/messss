export type MealType = 'Breakfast' | 'Lunch' | 'Snacks' | 'Dinner';

export interface DayMenu {
  Breakfast: string;
  Lunch: string;
  Snacks: string;
  Dinner: string;
}

export interface WeeklyTimetable {
  [key: string]: DayMenu;
}

export const MESS_DATA: Record<string, WeeklyTimetable> = {
  "Safal Mess (Boys: Block 6, 8)": {
    "Sunday": {
      "Breakfast": "UTHAPPAM, SAMBHAR, CHUTNEY, SPROUTS, BANANA, BOILED EGG, BREAD, BUTTER, JAM, TEA, MILK, COFFEE",
      "Lunch": "VEG BIRYANI, CHICKEN BIRYANI, DAL KOLHAPURI, BUTTER PANEER MASALA, SAMBHAR, ONION RAITA, PICKLE",
      "Snacks": "WHITE SAUCE PASTA, SAUCE/CHUTNEY, TEA, COFFEE, MILK",
      "Dinner": "ALOO WHITE PEAS MASALA, DAL MAKHANI, PLAIN RICE, ROTI, SOUTH INDIAN PLAIN RICE, VEG SORBA SOUP, PARUPPU RASAM, HALWA"
    },
    "Monday": {
      "Breakfast": "IDLI, SAMBHAR, CHUTNEY, BANANA, BREAD, BUTTER, JAM, TEA, MILK, COFFEE",
      "Lunch": "TAWA ROTI, ALOO MUTTER RASSA, DAL FRY, MIX SALAD, BUTTER MILK, TOMATO RICE (NORTH & SOUTH), MORE KUZHAMBU, RAW BANANA PORIYAL, PAPER RASAM, PICKLE",
      "Snacks": "BHELPURI, TAMARIND CHUTNEY, TEA, COFFEE, MILK",
      "Dinner": "KADHAI MIX VEG, EGG GRAVY, DAL FRY, PLAIN RICE (NORTH & SOUTH), BUTTER ROTI, MULTI GRAIN KHICHDI, VEG PORIYAL, TOMATO RASAM, RICE KHEER, PICKLE"
    },
    "Tuesday": {
      "Breakfast": "POHA, PONGAL CHUTNEY, JEERA MAN, MIX CUTFROIT SALAD, BREAD, BUTTER, JAM, TEA, MILK, COFFEE",
      "Lunch": "WHITE CHANA (SPICY), MIX DAL, MINT RICE (NORTH & SOUTH), PLAIN ROTI, FRYUMS, BUTTER MILK/JUICE, SOUTH INDIAN PLAIN RICE, BOTTLE GOURD KUZHAMBU, TOMATO RASAM, PICKLE",
      "Snacks": "DAHI VADA / FRIED IDLI, GREEN CHUTNEY, SAUCE, TEA, COFFEE, MILK",
      "Dinner": "MIX VEG, DAL TADKA, PLAIN RICE (NORTH & SOUTH), BUTTER ROTI / PLAIN ROTI, FRUIT CUSTARD, PAPER RASAM, PICKLE"
    },
    "Wednesday": {
      "Breakfast": "PAV BHAJI / UPMA, CHUTNEY, SPROUTS, BANANA, BOILED EGG, BREAD, BUTTER, JAM, TEA, MILK, COFFEE",
      "Lunch": "DAL TADKA, MUTTER PULAO, ROTI, FRYUMS, LOBIA MASALA, SOUTH INDIAN PLAIN RICE, VEGETABLE SAMBHAR, SWEET BOONDI, PARUPPU RASAM, PICKLE",
      "Snacks": "PANIPURI, RED CHILLI SAUCE, TEA, COFFEE, MILK",
      "Dinner": "PANEER MASALA (OILY & SPICY), KADAI CHICKEN MASALA (OILY & SPICY), PLAIN DAL, PLAIN RICE (NORTH & SOUTH), BUTTER ROTI / PLAIN ROTI, INJI RASAM, PICKLE"
    },
    "Thursday": {
      "Breakfast": "RAVA KHICHDI, PONGAL, ONION TOMATO CHUTNEY, COCONUT CHUTNEY, BANANA, BREAD, BUTTER, JAM, TEA, MILK, COFFEE",
      "Lunch": "RAJMA, VEG SAMBHAR, JEERA RICE, PLAIN ROTI, SEASONAL VEG, MIX VEG SALAD, PLAIN RICE, BEETROOT PORIYAL, RASAM, PICKLE",
      "Snacks": "NOODLES / FRIED IDLI, SAUCE / COCONUT CHUTNEY, TEA, COFFEE, MILK",
      "Dinner": "EGG GRAVY, GREEN PEAS MASALA, DAL FRY, JEERA RICE, BUTTER ROTI, SOOJI HALWA, PAPER RASAM, PICKLE"
    },
    "Friday": {
      "Breakfast": "DALIYA, POHA, BOILED EGG, BREAD, BUTTER, JAM, TEA, MILK, COFFEE, FRUIT SALAD",
      "Lunch": "LAUKI CHANA MASALA, DAL FRY, STEAMED RICE, TAWA ROTI, MIX SALAD, CURD, PICKLE, PAPAD",
      "Snacks": "BLACK CHANNA SUNDAL, TEA, COFFEE, MILK, BISCUITS",
      "Dinner": "CHICKEN MASALA, KADAI PANEER, DAL TADKA, STEAMED RICE, BUTTER ROTI, DESSERT, RASAM, PICKLE"
    },
    "Saturday": {
      "Breakfast": "UTHAPPAM, CHUTNEY, SAMBHAR, MIX CUTFROIT SALAD, BREAD, BUTTER, JAM, TEA, MILK, COFFEE",
      "Lunch": "ALOO PALAK, GARLIC DAL, GHEE RICE, ROTI, BUTTER MILK, CURD, SOUTH INDIAN PLAIN RICE, POTATO PORIYAL, RASAM, PICKLE",
      "Snacks": "SWEET CORN SALAD, RED TOMATO CHUTNEY, TEA, COFFEE, MILK",
      "Dinner": "VEG PULAO, LOBIA GRAVY, TOOR DAL FRY, ROTI, SOUTH INDIAN PLAIN RICE, PORUPPU RASAM, PICKLE"
    }
  },
  "Rassense Mess (Boys: Block 1)": {
    "Monday": { "Breakfast": "Dosa, Sambhar", "Lunch": "Fried Rice", "Snacks": "Samosa", "Dinner": "Dal Makhani" },
    "Tuesday": { "Breakfast": "Puri Bhaji", "Lunch": "Chole Bhature", "Snacks": "Pakora", "Dinner": "Mix Veg" },
    "Wednesday": { "Breakfast": "Poha", "Lunch": "Veg Pulao", "Snacks": "Cutlet", "Dinner": "Paneer Tikka" },
    "Thursday": { "Breakfast": "Idli Wada", "Lunch": "Rajma Masala", "Snacks": "Bhel", "Dinner": "Egg Curry" },
    "Friday": { "Breakfast": "Paratha", "Lunch": "Kadhi Pakora", "Snacks": "Vada Pav", "Dinner": "Chicken Curry" },
    "Saturday": { "Breakfast": "Upma", "Lunch": "Biryani", "Snacks": "Corn Chat", "Dinner": "Fish Curry" },
    "Sunday": { "Breakfast": "Sandwich", "Lunch": "Thali Special", "Snacks": "Patties", "Dinner": "Mutton Curry" }
  },
  "Mayuri Mess (Boys: Block 2-5, 7)": {
    "Monday": { "Breakfast": "Dosa, Sambhar", "Lunch": "Fried Rice", "Snacks": "Samosa", "Dinner": "Dal Makhani" },
    "Tuesday": { "Breakfast": "Puri Bhaji", "Lunch": "Chole Bhature", "Snacks": "Pakora", "Dinner": "Mix Veg" },
    "Wednesday": { "Breakfast": "Poha", "Lunch": "Veg Pulao", "Snacks": "Cutlet", "Dinner": "Paneer Tikka" },
    "Thursday": { "Breakfast": "Idli Wada", "Lunch": "Rajma Masala", "Snacks": "Bhel", "Dinner": "Egg Curry" },
    "Friday": { "Breakfast": "Paratha", "Lunch": "Kadhi Pakora", "Snacks": "Vada Pav", "Dinner": "Chicken Curry" },
    "Saturday": { "Breakfast": "Upma", "Lunch": "Biryani", "Snacks": "Corn Chat", "Dinner": "Fish Curry" },
    "Sunday": { "Breakfast": "Sandwich", "Lunch": "Thali Special", "Snacks": "Patties", "Dinner": "Mutton Curry" }
  },
  "JMB Mess (Boys)": {
    "Monday": { "Breakfast": "Dosa, Sambhar", "Lunch": "Fried Rice", "Snacks": "Samosa", "Dinner": "Dal Makhani" },
    "Tuesday": { "Breakfast": "Puri Bhaji", "Lunch": "Chole Bhature", "Snacks": "Pakora", "Dinner": "Mix Veg" },
    "Wednesday": { "Breakfast": "Poha", "Lunch": "Veg Pulao", "Snacks": "Cutlet", "Dinner": "Paneer Tikka" },
    "Thursday": { "Breakfast": "Idli Wada", "Lunch": "Rajma Masala", "Snacks": "Bhel", "Dinner": "Egg Curry" },
    "Friday": { "Breakfast": "Paratha", "Lunch": "Kadhi Pakora", "Snacks": "Vada Pav", "Dinner": "Chicken Curry" },
    "Saturday": { "Breakfast": "Upma", "Lunch": "Biryani", "Snacks": "Corn Chat", "Dinner": "Fish Curry" },
    "Sunday": { "Breakfast": "Sandwich", "Lunch": "Thali Special", "Snacks": "Patties", "Dinner": "Mutton Curry" }
  },
  "AB Caterers (Girls: Block 1)": {
    "Monday": { "Breakfast": "Dosa, Sambhar", "Lunch": "Fried Rice", "Snacks": "Samosa", "Dinner": "Dal Makhani" },
    "Tuesday": { "Breakfast": "Puri Bhaji", "Lunch": "Chole Bhature", "Snacks": "Pakora", "Dinner": "Mix Veg" },
    "Wednesday": { "Breakfast": "Poha", "Lunch": "Veg Pulao", "Snacks": "Cutlet", "Dinner": "Paneer Tikka" },
    "Thursday": { "Breakfast": "Idli Wada", "Lunch": "Rajma Masala", "Snacks": "Bhel", "Dinner": "Egg Curry" },
    "Friday": { "Breakfast": "Paratha", "Lunch": "Kadhi Pakora", "Snacks": "Vada Pav", "Dinner": "Chicken Curry" },
    "Saturday": { "Breakfast": "Upma", "Lunch": "Biryani", "Snacks": "Corn Chat", "Dinner": "Fish Curry" },
    "Sunday": { "Breakfast": "Sandwich", "Lunch": "Thali Special", "Snacks": "Patties", "Dinner": "Mutton Curry" }
  },
  "Mayuri Mess (Girls: Block 2 + Special Block)": {
    "Monday": { "Breakfast": "Dosa, Sambhar", "Lunch": "Fried Rice", "Snacks": "Samosa", "Dinner": "Dal Makhani" },
    "Tuesday": { "Breakfast": "Puri Bhaji", "Lunch": "Chole Bhature", "Snacks": "Pakora", "Dinner": "Mix Veg" },
    "Wednesday": { "Breakfast": "Poha", "Lunch": "Veg Pulao", "Snacks": "Cutlet", "Dinner": "Paneer Tikka" },
    "Thursday": { "Breakfast": "Idli Wada", "Lunch": "Rajma Masala", "Snacks": "Bhel", "Dinner": "Egg Curry" },
    "Friday": { "Breakfast": "Paratha", "Lunch": "Kadhi Pakora", "Snacks": "Vada Pav", "Dinner": "Chicken Curry" },
    "Saturday": { "Breakfast": "Upma", "Lunch": "Biryani", "Snacks": "Corn Chat", "Dinner": "Fish Curry" },
    "Sunday": { "Breakfast": "Sandwich", "Lunch": "Thali Special", "Snacks": "Patties", "Dinner": "Mutton Curry" }
  }
};

export const MESS_LIST = Object.keys(MESS_DATA);
